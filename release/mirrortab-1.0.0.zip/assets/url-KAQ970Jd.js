function n(r){const t=r.trim();return t?/^https?:\/\//i.test(t)?t:`https://${t}`:""}export{n};
